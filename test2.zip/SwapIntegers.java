/*
 * this programs swaps two integer variables by means of arithmetic
 */
public class SwapIntegers {

	public static void main(String[] args) {
		// declare and initialise variables
		int num1=10;
		int num2=7;
		
		//display variables before swap
		System.out.format("%nBefore swap: num1 is '%d' and num2 is '%d'", num1, num2);
		
		//Swap Step 1: add value of num2 to value of num1
		num1 =  num1 + num2;
		
		//Swap Step 2: set num2 to be difference between new num1 and num2
		num2 = num1 - num2;
		
		//Swap Step 3: set num1 to be difference between new num1 and new num2
		num1 = num1 - num2;
		
		//display main variables after swap
		System.out.format("%nAfter swap: num1 is '%d' and num2 is '%d'", num1, num2);
	}
}

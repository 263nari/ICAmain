#!/bin/bash
#
# This Bash program uses awk to find occurrences of fast food restaurents
#
#change default bash record separator from space to semi colon
IFS=$';'

#set input file
inputfile="gps.log"

#srt patterns to match
pattern1="Burger king"
pattern2="Mcdonald's"

#execute awk script to find visits to Burger king
bkCount=`awk 'BEGIN { FS = ","; n = 0} $2 ~ /.'${pattern1}'/ {++n} END {print n}' $inputfile`

#execute awk script to find visits to Mcdonald's
mcCount=`awk 'BEGIN { FS = ","; n = 0} $2 ~ /.'${pattern2}'/ {++n} END {print n}' $inputfile`

#compare visits
if [ $bkCount -gt $mcCount ];
then
	echo "Burger King ($bkCount) visted more times than Mcdonald's ($mcCount)"
elif [ $bkCount -lt $mcCount ];
then
	echo "Mcdonald's ($mcCount) visted more times than Burger King ($bkCount)"
else
	echo "Burger King ($bkCount) visted same amount of times as Mcdonald's ($mcCount)"
fi
